/*!
 * \file   main.cpp
 * \authors Alain Casali, Marc Laporte
 * \date december 8 2016
 * \brief   Terminal's color management
 *          beginning of the project titled "catch me if you can"
 */

// interface graphique + sprite
#define FPS_LIMIT 60
#include <thread>
#include "mingl/mingl.h"
#include "mingl/gui/sprite.h"
#include "mingl/shape/rectangle.h"
#include "mingl/gui/text.h"

// sans interface graphique
#include <iostream>
//#include "Correc_Prof/game.h"
#include <vector>
//#include "./Nos_fichiers/config.yaml"

/* Mes sources :
 *  - Generation Carte Pacman MAZE : https://shaunlebron.github.io/pacman-mazegen/
 *  - Cheat sheet : https://siddharthqs.com/the-essential-c-stl-cheat-sheet
 */

using namespace std;
nsGraphics::Vec2D rectPos;

typedef unsigned int UInt_t;
typedef const unsigned int CUINT_t;
typedef vector<int> CVLine;
typedef vector<CVLine> CMatrix;
typedef pair<unsigned int, unsigned int> CPosition;

/**
 * @brief Met à jour la position du joueur
 * @authors Enzo Cordovana, El-Kassouf Simon
 * @param[in] window : Fenêtre de l'interface graphique
 * @param[in] positionJoueur: Position du joueur
 * @param[in] carte : Carte du jeu
 * @fn void clavier(MinGL &window, CPosition &positionJoueur,const CMatrix &carte);
 */
void clavier(MinGL &window, CPosition &positionJoueur,const CMatrix &carte) {
    // static permet de garder la valeur de la variable comme un cache vulgairement
    // source : https://www.w3schools.com/cpp/ref_keyword_static.asp
    static bool haut = false;
    static bool bas = false;
    static bool gauche = false;
    static bool droit = false;

    // Vérification des entrées utilisateur et mise à jour de l'état des directions
    // bloque les diagonales
    /* Déplacement vers le bas */
    if ((window.isPressed({'s', false}) || bas) && carte[positionJoueur.first][positionJoueur.second+1]!=1) { // S
        positionJoueur.second +=1;
        bas = true;
        haut = gauche = droit = false;
        // Evite de bug le deplacement en appuyant sur les touches opposées en meme temps
        window.resetKey({'s', false});
    /* Déplacement vers le haut */
    } else if ((window.isPressed({'z', false}) || haut) && carte[positionJoueur.first][positionJoueur.second-1]!=1) { // Z
        positionJoueur.second -=1;
        haut = true;
        bas = gauche = droit = false;
        // Evite de bug le deplacement en appuyant sur les touches opposées en meme temps
        window.resetKey({'z', false});
    /* Déplacement vers le droite */
    } else if ((window.isPressed({'q', false}) || gauche) && carte[positionJoueur.first-1][positionJoueur.second]!=1) { // Q
        positionJoueur.first -=1;
        gauche = true;
        haut = bas = droit = false;
        // Evite de bug le deplacement en appuyant sur les touches opposées en meme temps
        window.resetKey({'q', false});
    /* Déplacement vers la gauche */
    } else if ((window.isPressed({'d', false}) || droit) && carte[positionJoueur.first+1][positionJoueur.second]!=1) { // D
        positionJoueur.first +=1;
        droit = true;
        haut = bas = gauche = false;
        // Evite de bug le deplacement en appuyant sur les touches opposées en meme temps
        window.resetKey({'d', false});
    }
}

/**
 * @brief Afficher le joueur sur la carte en fonction de sa position
 * @param[in] window : Fenêtre de l'interface graphique
 * @param[in] taille : Taille d'une cellule de la carte
 * @param[in] positionJoueur: Position du joueur
 * @fn void dessiner(MinGL &window, const unsigned int taille, CPosition &positionJoueur);
 */
void dessiner(MinGL &window, const unsigned int taille, CPosition &positionJoueur) {
    rectPos = nsGraphics::Vec2D(taille * positionJoueur.first, taille * positionJoueur.second);
    window << nsShape::Rectangle(rectPos, rectPos + nsGraphics::Vec2D(taille, taille), nsGraphics::KCyan);
}

/**
 * @brief Afficher la position du joueur dans le texte
 * @param[in] window : Fenêtre de l'interface graphique
 * @param[in] positionJoueur: Position du joueur
 * @fn afficherPositionJoueur(MinGL &window, CPosition &positionJoueur);
 */
void afficherPositionJoueur(MinGL &window, CPosition &positionJoueur) {
    // Construire la chaîne "(x, y)" manuellement
    std::string texte = "(" + to_string(positionJoueur.first) + ", " + to_string(positionJoueur.second) + ")";
    window << nsGui::Text(nsGraphics::Vec2D(275, 20), texte, nsGraphics::KWhite);
}


/**
 * @brief Afficher la carte dans le terminal
 * @param[in] Carte : Carte du jeu
 * @fn afficherCarteTerminal(const vector<vector<T>> & Carte);
 */
template <typename T>
void  afficherCarteTerminal(const vector<vector<T>> &Carte) {
    for (const vector<T>& indiceLigne: Carte) {
        // parcours des cellules
        for (const T& tuile: indiceLigne) {
            switch(tuile) {
            // piece vide || chemin
            case 0:
                cout << 0 << " ";
                break;
            // piece I || mur
            case 1:
                cout << 1 << " ";
                break;
            // piece L
            case 2:
                cout << 2 << " ";
                break;
            // piece T
            case 3:
                cout << 3 << " ";
                break;
            // piece +
            case 4:
                cout << 4 << " ";
                break;
            }
        }
        cout << endl;
    }
}

/**
 * @brief Afficher la carte dans l'interface graphique MinGL en regardant les cellules voisines pour générer le bon sprite
 * @param[in] Carte : Carte du jeu
 * @param[in] window : fentre de l'interface graphique MinGL
 * @fn afficherCarteInterface(const vector<vector<I>> &Carte, MinGL &window);
 */
template <typename I>
void afficherCarteInterface(const vector<vector<I>> &Carte, MinGL &window) {
    // Taille d'une cellule en pixels
    const unsigned int taille = 32;
    const unsigned int espacementFenetre = 0;

    bool enHaut;
    bool enBas;
    bool aGauche;
    bool aDroite;
    bool enHautAGauche;
    bool enHautADroite;
    bool enBasAGauche;
    bool enBasADroite;
    // Parcours de la grille interieur
    for (unsigned int indiceLigne (1); indiceLigne < Carte.size() - 1; ++indiceLigne) {
        for (unsigned int indiceColonne (1); indiceColonne < Carte[indiceLigne].size() - 1; ++indiceColonne) {
            // Récupérer les cellules voisines, si c'est un mur ou pas
            enHaut = (indiceLigne > 0 && Carte[indiceLigne - 1][indiceColonne] == 1);
            enBas = (indiceLigne < Carte.size() - 1 && Carte[indiceLigne + 1][indiceColonne] == 1);
            aGauche = (indiceColonne > 0 && Carte[indiceLigne][indiceColonne - 1] == 1);
            aDroite = (indiceColonne < Carte[indiceLigne].size() - 1 && Carte[indiceLigne][indiceColonne + 1] == 1);
            enHautAGauche = (indiceLigne > 0 && indiceColonne > 0 && Carte[indiceLigne - 1][indiceColonne - 1] == 1);
            enHautADroite = (indiceLigne > 0 && indiceColonne < Carte[indiceLigne].size() - 1 && Carte[indiceLigne - 1][indiceColonne + 1] == 1);
            enBasAGauche = (indiceLigne < Carte.size() - 1 && indiceColonne > 0 && Carte[indiceLigne + 1][indiceColonne - 1] == 1);
            enBasADroite = (indiceLigne < Carte.size() - 1 && indiceColonne < Carte[indiceLigne].size() - 1 && Carte[indiceLigne + 1][indiceColonne + 1] == 1);

            /* Gestion des sprites en fonction des cellules voisines */
            switch (Carte[indiceLigne][indiceColonne]) {
            case 1: { // Mur
                if (enHaut && aGauche && !aDroite && enBas) { // vertical gauche
                    window << nsGui::Sprite("../../res/carte/mur00000010.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (enHaut && !aGauche && aDroite && enBas) { // vertical droit
                    window << nsGui::Sprite("../../res/carte/mur00000100.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (!enHaut && aGauche && aDroite && enBas) { // horizontale bas
                    window << nsGui::Sprite("../../res/carte/mur00000001.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (enHaut && aGauche && aDroite && !enBas) { // horizontale haut
                    window << nsGui::Sprite("../../res/carte/mur00001000.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (!enHaut && !aGauche && aDroite && enBas) { // arrondi bas droit
                    window << nsGui::Sprite("../../res/carte/mur11110110.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (!enHaut && aGauche && !aDroite && enBas) { // arrondi bas gauche
                    window << nsGui::Sprite("../../res/carte/mur11110100.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (enHaut && !aGauche && aDroite && !enBas) { // arrondi haut droit
                    window << nsGui::Sprite("../../res/carte/mur11111101.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (enHaut && aGauche && !aDroite && !enBas) { // arrondi haut gauche
                    window << nsGui::Sprite("../../res/carte/mur11111011.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (enHautAGauche && !enHautADroite && enBasAGauche && enBasADroite) { // angle bas gauche
                    window << nsGui::Sprite("../../res/carte/mur00000011.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (!enHautAGauche && enHautADroite && enBasAGauche && enBasADroite) { // angle bas droit
                    window << nsGui::Sprite("../../res/carte/mur00000101.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (enHautAGauche && enHautADroite && enBasAGauche && !enBasADroite) { // angle haut gauche
                    window << nsGui::Sprite("../../res/carte/mur00001010.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else if (enHautAGauche && enHautADroite && !enBasAGauche && enBasADroite) { // angle haut droit
                    window << nsGui::Sprite("../../res/carte/mur00001100.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                } else { // Mur standard
                    window << nsGui::Sprite("../../res/carte/mur11111111.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                }
                break;
            }
            case 0: { // Chemin
                window << nsGui::Sprite("../../res/carte/mur00000000.si2",
                                        nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                          espacementFenetre + (taille * indiceLigne)));
                break;
            }
            }
        }
    }
    //Angles de la grille
    for (unsigned int indiceLigne (0); indiceLigne < Carte.size(); ++indiceLigne) {
        for (unsigned int indiceColonne (0); indiceColonne < Carte[indiceLigne].size(); ++indiceColonne) {
            if (indiceLigne == 0 && indiceColonne == 0) { // en haut à gauche
                window << nsGui::Sprite("../../res/carte/mur00001010.si2",
                                        nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                          espacementFenetre + (taille * indiceLigne)));
            }
            if (indiceLigne == 0 && indiceColonne == Carte[indiceLigne].size()-1) { // en haut à droite
                window << nsGui::Sprite("../../res/carte/mur00001100.si2",
                                        nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                          espacementFenetre + (taille * indiceLigne)));
            }
            if (indiceLigne == Carte.size()-1 && indiceColonne == 0) { // en bas à gauche
                window << nsGui::Sprite("../../res/carte/mur00000011.si2",
                                        nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                          espacementFenetre + (taille * indiceLigne)));
            }
            if (indiceLigne == Carte.size()-1 && indiceColonne == Carte[indiceLigne].size()-1) { // en bas à droite
                window << nsGui::Sprite("../../res/carte/mur00000101.si2",
                                        nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                          espacementFenetre + (taille * indiceLigne)));
            }
        }
    }
    //Parcours du reste
    for (unsigned int indiceLigne (0); indiceLigne < Carte.size(); ++indiceLigne) {
        for (unsigned int indiceColonne (0); indiceColonne < Carte[indiceLigne].size(); ++indiceColonne) {
            enHaut = (indiceLigne > 0 && Carte[indiceLigne - 1][indiceColonne] == 1);
            enBas = (indiceLigne < Carte.size() - 1 && Carte[indiceLigne + 1][indiceColonne] == 1);
            aGauche = (indiceColonne > 0 && Carte[indiceLigne][indiceColonne - 1] == 1);
            aDroite = (indiceColonne < Carte[indiceLigne].size() - 1 && Carte[indiceLigne][indiceColonne + 1] == 1);
            enHautAGauche = (indiceLigne > 0 && indiceColonne > 0 && Carte[indiceLigne - 1][indiceColonne - 1] == 1);
            enHautADroite = (indiceLigne > 0 && indiceColonne < Carte[indiceLigne].size() - 1 && Carte[indiceLigne - 1][indiceColonne + 1] == 1);
            enBasAGauche = (indiceLigne < Carte.size() - 1 && indiceColonne > 0 && Carte[indiceLigne + 1][indiceColonne - 1] == 1);
            enBasADroite = (indiceLigne < Carte.size() - 1 && indiceColonne < Carte[indiceLigne].size() - 1 && Carte[indiceLigne + 1][indiceColonne + 1] == 1);

            //mur de gauche
            if (indiceColonne == 0 && indiceLigne != 0 && indiceLigne != Carte.size()-1){
                switch (Carte[indiceLigne][0]) {
                case 1:
                    if (enBas && enHaut && aDroite && enBasADroite && enHautADroite ) {
                        window << nsGui::Sprite("../../res/carte/mur11111111.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else if (enBas && enHaut && aDroite && !enBasADroite && enHautADroite ) {
                        window << nsGui::Sprite("../../res/carte/mur00001010.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else if (enBas && enHaut && aDroite && enBasADroite && !enHautADroite ) { // mur plein
                        window << nsGui::Sprite("../../res/carte/mur00000011.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else {
                        window << nsGui::Sprite("../../res/carte/mur00000010.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    }
                    break;
                case 0:
                    window << nsGui::Sprite("../../res/carte/mur00000000.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                    break;
                }
            }
            //mur de droite
            if (indiceColonne == Carte[indiceLigne].size()-1 && indiceLigne != 0 && indiceLigne != Carte.size()-1){
                switch (Carte[indiceLigne][0]) {
                case 1:
                    if (enBas && enHaut && aGauche && enBasAGauche && enHautAGauche) {
                        window << nsGui::Sprite("../../res/carte/mur11111111.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else if (enBas && enHaut && aGauche && !enBasAGauche && enHautAGauche) {
                        window << nsGui::Sprite("../../res/carte/mur00001100.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else if (enBas && enHaut && aGauche && enBasAGauche && !enHautAGauche) { // mur plein
                        window << nsGui::Sprite("../../res/carte/mur00000101.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else {
                        window << nsGui::Sprite("../../res/carte/mur00000100.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    }
                    break;
                case 0:
                    window << nsGui::Sprite("../../res/carte/mur00000000.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                    break;
                }
            }
            //mur du haut
            if (indiceLigne == 0 && indiceColonne != 0 && indiceColonne != Carte[indiceLigne].size()-1){
                switch (Carte[indiceLigne][0]) {
                case 1:
                    if (enBas && aDroite && aGauche && enBasADroite && !enBasAGauche) {
                        window << nsGui::Sprite("../../res/carte/mur00001100.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else if (enBas && aDroite && aGauche && !enBasADroite && enBasAGauche) {
                        window << nsGui::Sprite("../../res/carte/mur00001010.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else if (enBas && aDroite && aGauche && enBasADroite && enBasAGauche) { // mur plein
                        window << nsGui::Sprite("../../res/carte/mur11111111.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else {
                        window << nsGui::Sprite("../../res/carte/mur00001000.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    }
                    break;
                case 0:
                    window << nsGui::Sprite("../../res/carte/mur00000000.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                    break;
                }
            }
            //mur du bas
            if (indiceLigne == Carte.size()-1 && indiceColonne != 0 && indiceColonne != Carte[indiceLigne].size()-1){
                switch (Carte[indiceLigne][0]) {
                case 1:
                    if (enHaut && aDroite && aGauche && enHautADroite && !enHautAGauche) {
                        window << nsGui::Sprite("../../res/carte/mur00000101.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else if (enHaut && aDroite && aGauche && !enHautADroite && enHautAGauche) {
                        window << nsGui::Sprite("../../res/carte/mur00000011.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else if (enHaut && aDroite && aGauche && enHautADroite && enHautAGauche) { // mur plein
                        window << nsGui::Sprite("../../res/carte/mur11111111.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    } else {
                        window << nsGui::Sprite("../../res/carte/mur00000001.si2",
                                                nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                                  espacementFenetre + (taille * indiceLigne)));
                    }
                    break;
                case 0:
                    window << nsGui::Sprite("../../res/carte/mur00000000.si2",
                                            nsGraphics::Vec2D(espacementFenetre + (taille * indiceColonne),
                                                              espacementFenetre + (taille * indiceLigne)));
                    break;
                }
            }
        }
    }
}

/* Tableau qui contient les pièces */
vector<CMatrix> stockPieces = {
    { // 0 = I
        {1,1,1},
        {1,1,1},
        {1,1,1},
    },
    { // 1 = L
        {1,0,0},
        {1,0,0},
        {1,1,1},
    },
    { // 2 = T
        {1,1,1},
        {0,1,0},
        {0,1,0},
    },
    { // 3 = +
        {0,1,0},
        {1,1,1},
        {0,1,0},
    },
    { // 4 = L
        {1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,0,1},
        {1,0,1,1,1,1,0,1},
        {1,0,1,1,1,1,0,1},
        {1,0,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1},
    },
    {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
        {1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,1},
        {1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1},
        {1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1},
        {1,0,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,1,0,1},
        {1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
        {1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
    }
};



/**
 * @brief Afficher la carte dans l'interface graphique MinGL en regardant les cellules voisines pour générer le bon sprite
 * @param[in] Carte : Carte du jeu
 * @param[in] window : fentre de l'interface graphique MinGL
 * @fn afficherCarteInterface(const vector<vector<I>> &Carte, MinGL &window);
 */
CMatrix genereCarteFactorisee() {
    const unsigned int NbrindiceColonne = 5;
    const unsigned int NbrindiceLigne = 9;
    srand(time(0));
    /* Parcours du tableau et ajout des pieces aléatoirement
     * 0 = I
     * 1 = L
     * 2 = T
     * 3 = +
     */
    /* Carte qui contient la premiere moitier des identifiants des pieces aléatoire */
    // Initialisation (CartePiece)
    CMatrix CartePiece = CMatrix(NbrindiceLigne, CVLine(NbrindiceColonne, 0));
    for (unsigned int indiceLigne (0); indiceLigne < NbrindiceLigne; ++indiceLigne) {
        for (unsigned int indiceColonne (0); indiceColonne < NbrindiceColonne; ++indiceColonne) {
            // Ajouter les pièces aléatoirement
            CartePiece[indiceLigne][indiceColonne] = (rand()%4)+1; // [1;4]
        }
    }

    /* Carte qui contient la symetri de (CartePiece) */
    // Initialisation (CartePieceSymetrie)
    CMatrix CartePieceSymetrie = CMatrix((NbrindiceLigne), CVLine((NbrindiceColonne), 0));
    // On copie la Carte 'CartePiece' (premiere motier) à 'CartePieceSymetrie'
    for (unsigned int indiceLigne (0); indiceLigne < NbrindiceLigne; ++indiceLigne) {
        for (unsigned int indiceColonne (0); indiceColonne < NbrindiceColonne; ++indiceColonne) {
            CartePieceSymetrie[indiceLigne][NbrindiceColonne - 1 -indiceColonne] = CartePiece[indiceLigne][indiceColonne];
        }
    }

    /* On reporte les deux carte pour faire une carte symetrique */
    // Initialisation
    CMatrix CarteFactorisee = CMatrix((NbrindiceLigne), CVLine((NbrindiceColonne*2), 0));

    for (unsigned int indiceLigne (0); indiceLigne < NbrindiceLigne; ++indiceLigne) { // Partie de gauche
        for (unsigned int indiceColonne (0); indiceColonne < NbrindiceColonne; ++indiceColonne) {
            CarteFactorisee[indiceLigne][indiceColonne] = CartePiece[indiceLigne][indiceColonne];
        }
    }
    for (unsigned int indiceLigne (0); indiceLigne < NbrindiceLigne; ++indiceLigne) { // Partie de droite
        for (unsigned int indiceColonne (NbrindiceColonne); indiceColonne < NbrindiceColonne*2; ++indiceColonne) {
            CarteFactorisee[indiceLigne][indiceColonne] = CartePieceSymetrie[indiceLigne][indiceColonne-NbrindiceColonne];
        }
    }

    /* On retourne la carte qui contient les identifiants des pièces*/
    return CarteFactorisee;
}



/**
 * @brief main
 * @return return 0 iff everything is OK, 1 if we have an exception, 2 if we can't load the params' file
 */
int main() {
    /* Carte de jeu (tilemap) */
    CMatrix tilemap = {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
        {1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,1},
        {1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1},
        {1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1},
        {1,0,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,1,0,1},
        {1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
        {1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,0,0,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1},
        {1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
    };


    // Position initial du joueur
    CPosition joueur1 = {1,1};

    srand(time(0));  // Initialiser le générateur de nombres aléatoires

    // Initialise le système
    MinGL window("Generation carte aleatoire", nsGraphics::Vec2D(992, 896), nsGraphics::Vec2D(10, 10), nsGraphics::KBlack);
    window.initGlut(); // Initialise la bibliothèque freeglut
    window.initGraphic(); // Initialise minGL et ouvre la fenêtre

    // Variable qui tient le temps de frame
    chrono::microseconds frameTime = chrono::microseconds::zero();

    // On fait tourner la boucle tant que la fenêtre est ouverte
    while (window.isOpen()) {
        // Récupère l'heure actuelle
        chrono::time_point<chrono::steady_clock> start = chrono::steady_clock::now();

        // Efface
        window.clearScreen();

        // Dessine la carte une seule fois
        afficherCarteInterface(stockPieces[5], window);

        // Mettre à jour et redessiner uniquement les éléments dynamiques
        clavier(window, joueur1, stockPieces[5]); // Contrôle joueur
        dessiner(window, 32, joueur1); // Ajout du personnage contrôlé
        //afficherPositionJoueur(window, joueur1); // Afficher la position du joueur

        // Finaliser la frame
        window.finishFrame();

        // Nettoyer les événements pour la frame suivante
        window.getEventManager().clearEvents();

        // Limiter le framerate
        this_thread::sleep_for(chrono::milliseconds(1000 / FPS_LIMIT) - chrono::duration_cast<chrono::microseconds>(chrono::steady_clock::now() - start));

        // Temps de la frame
        frameTime = chrono::duration_cast<chrono::microseconds>(chrono::steady_clock::now() - start);
    }
    return 0;

}
