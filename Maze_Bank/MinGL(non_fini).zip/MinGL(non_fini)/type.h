#ifndef TYPE_H
#define TYPE_H
/*!
 * \file type.h
 * \brief Definition of usefull types or aliases for the project
 * \author Alain Casali
 * \author Marc Laporte
 * \version 1.0
 * \date 18 décembre 2018
 */

#include <string>
#include <vector>

typedef unsigned int UInt_t;
typedef const unsigned int CUINT_t;
typedef vector<int> CVLine; // un type représentant une ligne de la grille
typedef vector<CVLine> CMatrix; // un type représentant la grille
typedef pair<unsigned int, unsigned int> CPosition; // un type représentant une coordonnée dans la grille

#endif // TYPE_H
